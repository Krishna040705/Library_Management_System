package com.library.fine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class FineDAO {
    private Connection getConnection() throws SQLException {
        // Implement connection to your PostgreSQL database
        // Adjust the JDBC URL, username, and password as needed
        return DriverManager.getConnection("jdbc:postgresql://localhost:5432/library", "username", "password");
    }

    // Method to calculate fines
    public Fine calculateFine(int userId) {
        Fine fine = new Fine();
        fine.setUserId(userId);

        try (Connection conn = getConnection()) {
            // Retrieve all borrowings for the user
            String query = "SELECT * FROM borrowings WHERE user_id = ? AND returned = false";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setInt(1, userId);
                ResultSet rs = ps.executeQuery();

                double totalFine = 0;
                Date currentDate = new Date();

                while (rs.next()) {
                    Date dueDate = rs.getDate("due_date");
                    if (currentDate.after(dueDate)) {
                        // Calculate fine (e.g., $1 per day)
                        long overdueDays = (currentDate.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24);
                        totalFine += overdueDays;  // Assuming $1 per day fine
                    }
                }

                fine.setAmount(totalFine);
                fine.setPaid(false);  // Assuming unpaid fine for now
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return fine;
    }

    // Method to update fine status (e.g., mark as paid)
    public boolean updateFineStatus(int fineId, boolean paid) {
        try (Connection conn = getConnection()) {
            String query = "UPDATE fines SET paid = ? WHERE fine_id = ?";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setBoolean(1, paid);
                ps.setInt(2, fineId);
                int rowsAffected = ps.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
