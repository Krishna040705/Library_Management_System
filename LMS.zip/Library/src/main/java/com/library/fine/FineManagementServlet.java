package com.library.fine;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public class FineManagementServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the userId from session or request
        int userId = Integer.parseInt(request.getParameter("userId"));

        // Calculate fine using FineDAO
        FineDAO fineDAO = new FineDAO();
        Fine fine = fineDAO.calculateFine(userId);

        // Set the fine object as a request attribute
        request.setAttribute("fine", fine);

        // Forward to the fine management JSP page to display the fine
        request.getRequestDispatcher("/fineManagement.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int fineId = Integer.parseInt(request.getParameter("fineId"));
        boolean paid = Boolean.parseBoolean(request.getParameter("paid"));

        FineDAO fineDAO = new FineDAO();
        boolean success = fineDAO.updateFineStatus(fineId, paid);

        if (success) {
            response.sendRedirect("fineManagement.jsp?success=true");
        } else {
            response.sendRedirect("fineManagement.jsp?error=true");
        }
    }
}
