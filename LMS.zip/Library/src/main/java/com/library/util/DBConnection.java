package com.library.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final String URL = "jdbc:postgresql://localhost:5432/db_11"; 
    private static final String USER = "postgres";  
    private static final String PASSWORD = "root";  

    public static Connection getConnection() {
        try {
            // Load the PostgreSQL driver if necessary (optional for newer JDBC)
            Class.forName("org.postgresql.Driver");

            // Directly establish the connection
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Database connection established.");
            return connection;

        } catch (ClassNotFoundException e) {
            System.err.println("PostgreSQL JDBC Driver not found.");
            e.printStackTrace();

        } catch (SQLException e) {
            System.err.println("Failed to establish database connection. Check URL, username, and password.");
            e.printStackTrace();
        }

        // Return null if connection fails
        return null;
    }
}
