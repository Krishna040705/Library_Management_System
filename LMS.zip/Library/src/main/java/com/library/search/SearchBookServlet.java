package com.library.search;

import com.library.book.Book;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/searchBook")
public class SearchBookServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String genre = request.getParameter("genre");

        // Debugging search parameters
        System.out.println("Search Parameters: Title=" + title + ", Author=" + author + ", Genre=" + genre);

        // Search for books
        List<Book> books = searchBooks(title, author, genre);

        // Check if no books were found
        if (books.isEmpty()) {
            request.setAttribute("message", "No books found matching your search criteria.");
        }

        // Set books as a request attribute
        request.setAttribute("books", books);

        // Forward the request to searchResults.jsp
        RequestDispatcher dispatcher = request.getRequestDispatcher("/searchResults.jsp");
        dispatcher.forward(request, response);
    }

    private List<Book> searchBooks(String title, String author, String genre) {
        List<Book> books = new ArrayList<>();

        // Mock data for search
        String[] sampleTitles = {
            "The Great Gatsby", "1984", "To Kill a Mockingbird", "Pride and Prejudice", 
            "The Catcher in the Rye", "The Hobbit", "Moby-Dick", "War and Peace", 
            "The Odyssey", "Brave New World", "asd", "jj", "jhh", "krishna", 
            "krishna", "Kirshna ", "krishna", "g", "gg", "l", "l", "f"
        };
        
        String[] sampleAuthors = {
            "F. Scott Fitzgerald", "George Orwell", "Harper Lee", "Jane Austen", 
            "J.D. Salinger", "J.R.R. Tolkien", "Herman Melville", "Leo Tolstoy", 
            "Homer", "Aldous Huxley", "qwe", "jn", "hh", "hhhy", 
            "sreenivas", "gfdssssssss", "sss", "g", "g", "jhgf", "jhgf", "f"
        };
        
        String[] sampleGenres = {
            "Fiction", "Dystopian", "Fiction", "Romance", "Fiction", "Fantasy", "Adventure", 
            "Historical", "Epic", "Science Fiction", "dfg", "jj", "hh", "comics", 
            "comics", "sssssssssss", "ssssssssss", "g", "gg", "hgf", "hgf", "f"
        };

        // Iterate over the data and check search criteria
        for (int i = 0; i < sampleTitles.length; i++) {
            if ((title != null && !title.isEmpty() && sampleTitles[i].toLowerCase().contains(title.toLowerCase())) ||
                (author != null && !author.isEmpty() && sampleAuthors[i].toLowerCase().contains(author.toLowerCase())) ||
                (genre != null && !genre.isEmpty() && sampleGenres[i].toLowerCase().contains(genre.toLowerCase()))) {
                
                // Create a book with availability set to true
                int bookId = (int) (Math.random() * 1000);  // Random book ID between 0 and 999
                books.add(new Book(sampleTitles[i], sampleAuthors[i], sampleGenres[i], true, bookId));
            }
        }

        return books;
    }
}
