package com.library.book;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import com.library.util.DBConnection;

public class BorrowDAO {

    // Original method with four parameters
    public boolean borrowBook(String userName, String bookName, Date borrowDate, Date dueDate) {
        int userId = getUserIdByName(userName);
        int bookId = getBookIdByName(bookName);

        if (userId == -1 || bookId == -1) {
            return false;
        }

        String sql = "INSERT INTO borrow (user_id, book_id, borrow_date, due_date) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            stmt.setInt(2, bookId);
            stmt.setDate(3, borrowDate);
            stmt.setDate(4, dueDate);

            int rowsInserted = stmt.executeUpdate();
            return rowsInserted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Overloaded method with only two parameters (userName and bookName)
    public boolean borrowBook(String userName, String bookName) {
        // Use current date as borrow date and set due date to 14 days from now
        Date borrowDate = Date.valueOf(LocalDate.now());
        Date dueDate = Date.valueOf(LocalDate.now().plusDays(14));

        return borrowBook(userName, bookName, borrowDate, dueDate);
    }

    private int getUserIdByName(String userName) {
        String sql = "SELECT user_id FROM users WHERE name = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, userName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("user_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int getBookIdByName(String bookName) {
        String sql = "SELECT book_id FROM books WHERE title = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, bookName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("book_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public boolean returnBook(int borrowId, Date returnDate) {
        String sql = "UPDATE borrow SET return_date = ? WHERE borrow_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDate(1, returnDate);
            stmt.setInt(2, borrowId);

            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
