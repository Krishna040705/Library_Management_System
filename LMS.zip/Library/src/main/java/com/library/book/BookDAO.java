package com.library.book;

import com.library.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {

    // Method to add a new book to the database
    public boolean addBook(Book book) {
        String sql = "INSERT INTO books (title, author, genre, available) VALUES (?, ?, ?, ?)";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            // Set parameters for the prepared statement
            statement.setString(1, book.getTitle());
            statement.setString(2, book.getAuthor());
            statement.setString(3, book.getGenre());
            statement.setBoolean(4, book.isAvailable());

            // Execute the update and check if rows were inserted
            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0;

        } catch (SQLException e) {
            System.err.println("Error adding book: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // Method to search for books by title, author, and genre
    public List<Book> searchBooks(String title, String author, String genre) {
        String sql = "SELECT * FROM Books WHERE (title LIKE ? OR ? IS NULL) AND (author LIKE ? OR ? IS NULL) AND (genre LIKE ? OR ? IS NULL)";
        List<Book> books = new ArrayList<>();

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            // Set parameters for the prepared statement with wildcard search
            statement.setString(1, "%" + (title != null ? title : "") + "%");
            statement.setString(2, title); // Pass the title as NULL if it's not provided
            statement.setString(3, "%" + (author != null ? author : "") + "%");
            statement.setString(4, author); // Pass the author as NULL if it's not provided
            statement.setString(5, "%" + (genre != null ? genre : "") + "%");
            statement.setString(6, genre); // Pass the genre as NULL if it's not provided

            // Execute the query and process the result set
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Book book = new Book(
                        resultSet.getString("title"),
                        resultSet.getString("author"),
                        resultSet.getString("genre"),
                        resultSet.getBoolean("available")
                    );
                    books.add(book);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error searching books: " + e.getMessage());
            e.printStackTrace();
        }

        return books;
    }

    // Method to retrieve all books from the database
    public List<Book> getAllBooks() {
        String sql = "SELECT * FROM books";
        List<Book> books = new ArrayList<>();

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Book book = new Book(
                        resultSet.getString("title"),
                        resultSet.getString("author"),
                        resultSet.getString("genre"),
                        resultSet.getBoolean("available")
                    );
                    books.add(book);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error fetching all books: " + e.getMessage());
            e.printStackTrace();
        }

        return books;
    }

    // Method to retrieve all books with pagination support
    public List<Book> getAllBooks(int offset, int limit) {
        String sql = "SELECT * FROM books LIMIT ? OFFSET ?";
        List<Book> books = new ArrayList<>();

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, limit);
            statement.setInt(2, offset);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Book book = new Book(
                        resultSet.getString("title"),
                        resultSet.getString("author"),
                        resultSet.getString("genre"),
                        resultSet.getBoolean("available")
                    );
                    books.add(book);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error fetching all books: " + e.getMessage());
            e.printStackTrace();
        }

        return books;
    }

    // Close any resources (like database connection) if necessary
    public void close() {
        // Here, DBConnection management can be handled if the connection is pooled.
        // No explicit connection closing here as it is handled by try-with-resources block
        // in each method where the connection is used.
        // However, if the connection was manually created and not managed via pooling, 
        // you would close it here.
        try {
            Connection connection = DBConnection.getConnection();
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing the connection: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
