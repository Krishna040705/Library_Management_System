package com.library.book;

public class Book {

    private int bookId;
    private String title;
    private String author;
    private String genre;
    private boolean available;

    // No-argument constructor
    public Book() {
    }

    // Constructor with title, author, genre, available, and a random bookId
    public Book(String title, String author, String genre, boolean available) {
        this.bookId = (int) (Math.random() * 1000);  // Generate a random book ID between 0 and 999
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.available = available;
    }

    // Constructor with bookId, title, author, genre, and available
    public Book(int bookId, String title, String author, String genre, boolean available) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.available = available;
    }

    // Constructor with parameters in a different order
    public Book(String string, String string2, String string3, boolean b, int bookId2) {
        // TODO Auto-generated constructor stub
    }

    // Getters and setters
    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    @Override
    public String toString() {
        return "Book{" +
                "bookId=" + bookId +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", genre='" + genre + '\'' +
                ", available=" + available +
                '}';
    }
}
