package com.library.book;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/addBook")
public class AddBookServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(AddBookServlet.class.getName());

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String genre = request.getParameter("genre");
        boolean available = request.getParameter("available") != null;

        // Log the retrieved values
        logger.log(Level.INFO, "Adding Book: {0}, {1}, {2}, Available: {3}", new Object[]{title, author, genre, available});

        // Create a Book object and populate it with form data
        Book book = new Book(title, author, genre, available);

        // Add the book to the database using BookDAO
        BookDAO bookDAO = new BookDAO();
        boolean success = bookDAO.addBook(book);

        // Redirect to a confirmation page or display a message
        if (success) {
            logger.log(Level.INFO, "Book added successfully: {0}", title);
            response.sendRedirect("confirmation.jsp");
        } else {
            logger.log(Level.WARNING, "Failed to add book: {0}", title);
            response.sendRedirect("addBook.jsp?error=true");  // Show error message if adding book fails
        }
    }
}
