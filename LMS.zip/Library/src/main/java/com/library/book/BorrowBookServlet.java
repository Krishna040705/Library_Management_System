package com.library.book;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/BorrowBookServlet")
public class BorrowBookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String bookName = request.getParameter("bookName");
        String userName = request.getParameter("userName");

        // Calculate due date (1 week from now)
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 7);
        Date dueDate = calendar.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDueDate = dateFormat.format(dueDate);

        // Set attributes for forwarding to the confirmation page
        request.setAttribute("bookName", bookName);
        request.setAttribute("userName", userName);
        request.setAttribute("dueDate", formattedDueDate);

        // Forward to confirmation page
        request.getRequestDispatcher("borrowConfirmation.jsp").forward(request, response);
    }
}
