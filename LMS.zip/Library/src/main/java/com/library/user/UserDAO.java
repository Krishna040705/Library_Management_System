package com.library.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.library.util.DBConnection;

public class UserDAO {
    public boolean validateUser(String username, String password) {
        try (Connection connection = DBConnection.getConnection()) {
            String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next(); // If there's a match, login is valid
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
