// src/com/library/user/RegisterServlet.java
package com.library.user;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public class RegisterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        String profileDetails = request.getParameter("profileDetails");

        // Create a User object and populate it with form data
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setRole(role);
        user.setProfileDetails(profileDetails);

        // Register the user using UserDAO
        UserDAO userDAO = new UserDAO();
        boolean success = userDAO.registerUser(user);

        // Redirect based on registration success or failure
        if (success) {
            response.sendRedirect("login.jsp");  // Redirect to login page on success
        } else {
            response.sendRedirect("register.jsp?error=true");  // Show error message on failure
        }
    }
}
